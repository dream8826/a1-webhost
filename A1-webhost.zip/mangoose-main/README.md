# mangoose
a simple webserver probably no updates  
it has php simple to use 
just download the file and run the exe
and type localhost in chrome or edge 
to edit just change the html file in html
i did not made this
someone made this and discontinued it
and i republished it 
